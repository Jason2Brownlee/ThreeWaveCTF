This archive contains two server prog files for NetQuake and QuakeWorld, both
updated to CTF4.21.  The NetQuake version fixes a logging bug and the
QuakeWorld version fixes a grapple bug.

Note that for logging to occur in the NetQuake version you must enable
the developer cvar (developer 1 at the console, or +developer 1 on the
command line).

Please download 4.2 for full documentation.
http://www.cdrom.com/pub/quake/planetquake/threewave/ctf/server/3wave42.zip

/// Zoid.
zoid@idsoftware.com

Dec '05/97

